package com.example.consumer.parallelconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParallelconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}

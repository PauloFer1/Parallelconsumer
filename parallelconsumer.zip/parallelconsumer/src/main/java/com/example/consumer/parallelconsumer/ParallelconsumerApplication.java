package com.example.consumer.parallelconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelconsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParallelconsumerApplication.class, args);
	}

}
